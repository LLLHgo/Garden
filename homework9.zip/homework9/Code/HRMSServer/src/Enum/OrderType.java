package Enum;

public enum OrderType {
	NORMALNONEXEC,NORMALEXEC,CANCEL,ABNORMAL;
}
