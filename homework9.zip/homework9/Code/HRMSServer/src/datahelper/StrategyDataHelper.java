package datahelper;

public class StrategyDataHelper {

}
