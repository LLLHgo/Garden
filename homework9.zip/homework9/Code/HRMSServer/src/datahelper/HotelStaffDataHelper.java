package datahelper;

public class HotelStaffDataHelper {

}
