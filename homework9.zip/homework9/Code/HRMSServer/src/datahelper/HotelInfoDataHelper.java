package datahelper;

public class HotelInfoDataHelper {

}
