package datahelper;

public class LogDataHelper {

}
