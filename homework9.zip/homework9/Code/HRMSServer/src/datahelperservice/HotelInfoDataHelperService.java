package datahelperservice;

public interface HotelInfoDataHelperService {

}
