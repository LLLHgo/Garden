package datahelperservice;

public interface StrategyDataHelperService {

}
