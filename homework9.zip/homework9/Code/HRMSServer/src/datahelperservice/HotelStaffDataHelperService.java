package datahelperservice;

public interface HotelStaffDataHelperService {

}
