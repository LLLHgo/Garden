package datahelperservice;

public interface DataFactoryService {

}
