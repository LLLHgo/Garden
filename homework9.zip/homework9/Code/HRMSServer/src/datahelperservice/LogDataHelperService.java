package datahelperservice;

public interface LogDataHelperService {

}
