package datahelperservice;

public interface SitemanagerDataHelperService {

}
