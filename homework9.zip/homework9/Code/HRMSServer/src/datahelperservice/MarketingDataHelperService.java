package datahelperservice;

public interface MarketingDataHelperService {

}
