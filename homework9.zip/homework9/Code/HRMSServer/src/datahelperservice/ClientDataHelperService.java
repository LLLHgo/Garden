package datahelperservice;

public interface ClientDataHelperService {

}
