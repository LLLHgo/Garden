package presentation.hotelstaff.view;

public interface HotelstaffViewControllerService {

}
