package presentation.hotelstaff.controller;

import presentation.hotelstaff.view.HotelstaffViewControllerService;

public class HotelstaffViewController implements HotelstaffViewControllerService{

}
