package presentation.hotelstaff.roominfo.view;

public interface RoominfoPanelControllerService {

}
