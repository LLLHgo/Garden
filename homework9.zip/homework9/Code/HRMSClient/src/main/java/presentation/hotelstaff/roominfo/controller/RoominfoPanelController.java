package presentation.hotelstaff.roominfo.controller;

import presentation.hotelstaff.roominfo.view.RoominfoPanel;

public class RoominfoPanelController {

	RoominfoPanel panel;
	
	public RoominfoPanelController(){
		
	}
	
	public void setPanel(RoominfoPanel panel){
		this.panel = panel;
	}
}
