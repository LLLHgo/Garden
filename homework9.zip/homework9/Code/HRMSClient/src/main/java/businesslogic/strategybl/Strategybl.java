package businesslogic.strategybl;

public class Strategybl {

}
