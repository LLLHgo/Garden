package businesslogic.setupbl;

public class SetUpbl {

}
