package businesslogic.logbl;

import java.util.List;

import Enum.ResultMessage;
import vo.logVO.LogVO;

public class LogManage {
	/**
	 * 界面得到日志列表
	 * @return 日志列表
	 */
	public List<LogVO> getLog(){
		return null;
	}
	/**
	 * 界面得到添加日志成功或失败信息
	 * @param logInfo
	 * @return 添加日志成功或失败的enum值
	 */
	public ResultMessage addLog (String logInfo){
		return null;
	}

}
