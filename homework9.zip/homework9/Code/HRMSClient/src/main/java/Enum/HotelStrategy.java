package Enum;

public enum HotelStrategy {
	BIRTHDAY,
    COMPANY,
    SPECIALDAY,
    OVERTHREEROOMS,
	CREATED;
}
