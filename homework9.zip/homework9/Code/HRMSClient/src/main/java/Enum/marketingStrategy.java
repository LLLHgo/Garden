package Enum;

public enum marketingStrategy {
    DOUBLE11,
    VIPSPECIAL,
    CRATEDE;
}
