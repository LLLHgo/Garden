package Enum;

public enum PrivilegeWay {
    DAILY,
    BIRTHDAY,
    ENTERPRISE;
}
