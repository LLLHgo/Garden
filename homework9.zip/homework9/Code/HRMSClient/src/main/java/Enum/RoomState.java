package Enum;

public enum RoomState {
	Usable,
	Unusable;
}
