package datatool;

import vo.levelVO.LevelVO;

public class LevelDataTool {
    public static LevelVO v1=new LevelVO(1,"铜牌",1000);
    public static LevelVO v2=new LevelVO(2,"银牌",1000);
    public static LevelVO v3=new LevelVO(3,"金牌",1000);
}
