package datatool;

import vo.hotelstaffVO.HotelstaffVO;

public class HotelstaffDataTool {
	
	public static HotelstaffVO hotelstaffVO1 = new HotelstaffVO("H00000001","00000000","12345678");
	public static HotelstaffVO hotelstaffVO2 = new HotelstaffVO("H00000002","00000000","12345679");
	public static HotelstaffVO hotelstaffVO3 = new HotelstaffVO("H00000003","00000000","12345670");

}
