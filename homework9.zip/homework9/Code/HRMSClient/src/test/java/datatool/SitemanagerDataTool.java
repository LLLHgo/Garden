package datatool;

import javax.swing.ImageIcon;

import vo.sitemanager.SitemanagerVO;

public class SitemanagerDataTool {
	static ImageIcon image=null;
	// checkAccount
	public static SitemanagerVO sitemanagerVO=new SitemanagerVO("S00000001","025-89988778","iloveHRMS",image);
}
