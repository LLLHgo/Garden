package Mock;

import Enum.ResultMessage;
import businesslogicservice.hotelstaffblservice.HotelstaffBLService;
import vo.hotelstaffVO.HotelstaffBasicinfoVO;
import vo.hotelstaffVO.HotelstaffVO;

public class MockHotelstaffManager implements HotelstaffBLService{
	
	
	
	public boolean saveSitemanagerUpdate(HotelstaffVO vo) {
		if(vo.getHotelID().equals("H00000001")){
			return true;
		}
		else if(vo.getHotelID().equals("H00000002")){
			return true;
		}
		else if(vo.getHotelID().equals("H00000003")){
			return true;
		}
		return false;
	}

	
	public HotelstaffVO returnSitemanagerAccount(String hotelID) {
		if(hotelID.equals("H00000001")){
			return new HotelstaffVO("H00000001","00000000","12345678");
		}
		else if(hotelID.equals("H00000002")){
			return new HotelstaffVO("H00000002","00000000","12345679");
		}
		else if(hotelID.equals("H00000003")){
			return new HotelstaffVO("H00000003","00000000","12345670");
		}
		else{
			return null;
		}
	}


	@Override
	public HotelstaffBasicinfoVO getBasicinfo(String hotelID) {
		return new HotelstaffBasicinfoVO("000000");
	}


	@Override
	public ResultMessage setPassword(String hotelID, String password) {
		return ResultMessage.SUCCESS;
	}


	@Override
	public boolean checkAccount(String hotelID, String password) {
		return true;
	}
}
