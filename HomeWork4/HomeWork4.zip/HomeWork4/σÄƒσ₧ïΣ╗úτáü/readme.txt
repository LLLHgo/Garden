助教好！
目前提交的代码是构件的部分代码框架，其中有写的是：
HRMSclient项目里：businesslogicservice（blservice,blservice_Stub,blservice_Driver)\po\vo\enum
HRMSserver项目里：
dataservice(dataservice,dataservice_Stub,dataservice_Driver)\po\enum
