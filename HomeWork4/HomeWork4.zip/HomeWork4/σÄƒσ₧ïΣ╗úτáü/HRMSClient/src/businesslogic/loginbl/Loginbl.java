package businesslogic.loginbl;

public class Loginbl {

}
