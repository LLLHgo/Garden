package businesslogic.logbl;

public class Logbl {

}
