package businesslogic.hotelstaffbl;

public class HotelStaffbl {

}
