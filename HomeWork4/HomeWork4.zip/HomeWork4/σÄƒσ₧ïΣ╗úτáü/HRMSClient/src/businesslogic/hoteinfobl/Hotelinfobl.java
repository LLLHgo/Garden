package businesslogic.hoteinfobl;


public class Hotelinfobl {

}
