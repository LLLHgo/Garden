package businesslogic.marketingbl;

public class Marketingbl {

}
