package businesslogic.sitemanagerbl;

public class SiteManagerbl {

}
