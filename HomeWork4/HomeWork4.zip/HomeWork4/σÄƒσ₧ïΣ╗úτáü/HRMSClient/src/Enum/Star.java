package Enum;

public enum Star {
	ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN;
}
