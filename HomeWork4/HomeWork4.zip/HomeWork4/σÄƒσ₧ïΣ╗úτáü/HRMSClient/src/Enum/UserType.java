package Enum;

public enum UserType {
	CLIENT,HOTELSTAFF,MARKETING,SITEMANAGER
}
