package Enum;

public enum VIPType {
    ORDINARYVIP,
    ENTERPRISEVIP;
}
