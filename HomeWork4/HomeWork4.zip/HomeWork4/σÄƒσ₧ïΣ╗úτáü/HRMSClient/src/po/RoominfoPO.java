package po;

public class RoominfoPO {

}
