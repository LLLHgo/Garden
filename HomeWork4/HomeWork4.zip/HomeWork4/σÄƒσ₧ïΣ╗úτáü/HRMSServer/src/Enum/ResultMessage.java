package Enum;

public enum ResultMessage {
    SUCCESS,
    FAIL;
}
