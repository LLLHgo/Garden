package po;

public class HotelStrategyPO {

}
