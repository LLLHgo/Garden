package data.hotelstaffdata;

public class HotelStaffData {

}
