package data.marketingdata;

public class MarketingData {

}
