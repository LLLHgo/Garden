package data.logdata;

public class LogData {

}
