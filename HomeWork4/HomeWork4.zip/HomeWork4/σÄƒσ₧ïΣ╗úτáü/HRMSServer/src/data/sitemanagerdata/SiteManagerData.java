package data.sitemanagerdata;

public class SiteManagerData {

}
