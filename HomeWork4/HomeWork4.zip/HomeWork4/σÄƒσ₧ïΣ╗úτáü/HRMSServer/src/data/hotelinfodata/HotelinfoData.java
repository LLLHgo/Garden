package data.hotelinfodata;

public class HotelinfoData {

}
