package data.strategydata;

public class StrategyData {

}
