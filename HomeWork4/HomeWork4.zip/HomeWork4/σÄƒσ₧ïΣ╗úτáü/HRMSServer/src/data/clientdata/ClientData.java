package data.clientdata;

public class ClientData {

}
